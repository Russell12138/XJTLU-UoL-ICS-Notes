import javafx.scene.paint.Color;

public class ColorPair {
    private Color color1;
    private Color color2;

    public ColorPair(Color color1,Color color2) {
        this.color1 = color1;
        this.color2 = color2;
    }

    public Color getColor1() {
        return color1;
    }

    public Color getColor2() {
        return color2;
    }
}
