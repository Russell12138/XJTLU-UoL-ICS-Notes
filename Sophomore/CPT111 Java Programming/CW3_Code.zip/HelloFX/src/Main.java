import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main extends Application {

    private Map<String,Integer> map = new LinkedHashMap<>();
    private int total_value;
    private String total_key;
    private String title;
    private List<ColorPair> colorList = new ArrayList<>();

    @Override
    //set primaryStage
    public void start(Stage primaryStage) {

        HBox hbox = new HBox(10);
        hbox.setAlignment(Pos.CENTER);
        hbox.setPadding(new Insets(20,20,20,20));
        Label label = new Label("Enter file name:");
        TextField textField = new TextField();
        textField.setPromptText("file name");
        Button button1 = new Button("Generate");
        Button button2 = new Button("Clear");
        button2.setOnAction(event -> {
            textField.clear();
        });
        hbox.getChildren().addAll(label,textField,button1,button2);
        button1.setOnAction(event -> {
            String fileName = textField.getText();

            //check exist
            if (!fileExists(fileName + ".txt")) {
                showAlert("The file name does not exist");
                textField.clear();
            }
            else {
                readFile(fileName + ".txt");
                initializeColorList();
                openSankeyDiagram();
            }
        });

        primaryStage.setTitle("Sankey Diagram Generator");
        primaryStage.setScene(new Scene(hbox,500,200));
        //set min to show full information
        primaryStage.setMinHeight(80);
        primaryStage.setMinWidth(450);
        primaryStage.show();
    }

    //method to read file and put into map
    private void readFile(String fileName) {
        map.clear();
        File file = new File(fileName);
        total_value = 0;
        //try with resources
        try (FileReader fileReader = new FileReader(file);
            BufferedReader reader = new BufferedReader(fileReader)){
            title = reader.readLine();
            total_key = reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                int lastSpaceIndex = line.lastIndexOf(" ");
                if (lastSpaceIndex != -1) {
                    String key = line.substring(0, lastSpaceIndex);
                    String valueStr = line.substring(lastSpaceIndex + 1);
                    try {
                        Integer value = Integer.parseInt(valueStr);
                        map.put(key, value);
                    } catch (NumberFormatException e) {
                        showError("Invalid integer format in line: " + line);
                        System.err.println("Invalid integer format in line: " + line);
                    }
                }
            }
        } catch (IOException ioe) {
            showError("Error reading file: " + ioe.getMessage());
            System.err.println("Error reading file: " + ioe.getMessage());
        }

        //add up the values
        for (Integer value : map.values()) {
            total_value += value;
        }
    }

    //method to show error
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    //method to check if file exists
    private boolean fileExists(String fileName) {
        File file = new File(fileName);
        return file.exists();
    }

    //method to alert if not exist
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    //method to set colorList
    private void initializeColorList() {
        colorList.add(0,new ColorPair(Color.color(1.0,0.5,0.31,0.7),Color.color(1.0,0.5,0.31,0.4)));
        colorList.add(1,new ColorPair(Color.color(0.2,0.8,0.8,0.7),Color.color(0.2,0.8,0.8,0.4)));
        colorList.add(2,new ColorPair(Color.color(0.7,0.5,0.8,0.7),Color.color(0.7,0.5,0.8,0.4)));
        colorList.add(3,new ColorPair(Color.color(0.13,0.34,0.8,0.7),Color.color(0.13,0.34,0.8,0.4)));
        colorList.add(4,new ColorPair(Color.color(1.0,0.4,0.6,0.7),Color.color(1.0,0.4,0.6,0.4)));
        colorList.add(5,new ColorPair(Color.color(0.2,0.8,0.2,0.7),Color.color(0.2,0.8,0.2,0.4)));
        colorList.add(6,new ColorPair(Color.color(0.9,0.6,0.0,0.7),Color.color(0.9,0.6,0.0,0.4)));
        colorList.add(7,new ColorPair(Color.color(0.12,0.84,1.0,0.7),Color.color(0.12,0.84,1.0,0.4)));
        colorList.add(8,new ColorPair(Color.color(0.92,0.23,0.4,0.7),Color.color(0.92,0.23,0.4,0.4)));
        colorList.add(9,new ColorPair(Color.color(0.0,0.7,0.6,0.7),Color.color(0.0,0.7,0.6,0.4)));
        colorList.add(10,new ColorPair(Color.color(0.92,0.53,0.7,0.7),Color.color(0.92,0.53,0.7,0.4)));
    }

    //method to draw rectangles
    private void drawRectangle(GraphicsContext gc,double x,double y,double width,double height,Color color) {
        gc.setFill(color);
        gc.fillRect(x,y,width,height);
        gc.strokeRect(x,y,width,height);
    }

    private void drawCurve(GraphicsContext gc,double leftX,double leftY,double rightX,double rightY,double single_height,Color color) {
        gc.setFill(color);
        gc.beginPath();
        gc.moveTo(leftX,leftY);
        gc.bezierCurveTo(leftX+0.25*rightX,leftY,rightX-0.25*rightX,rightY,rightX,rightY);
        rightY += single_height;
        gc.lineTo(rightX,rightY);
        leftY += single_height;
        gc.bezierCurveTo(rightX-0.25*rightX,rightY,leftX+0.25*rightX,leftY,leftX,leftY);
        gc.closePath();
        gc.fill();
    }

    //method to draw texts
    private void drawText(GraphicsContext gc,String text,double rightX,double rightY,Font font) {
        gc.setFont(font);
        gc.setFill(Color.BLACK);
        Text textObj = new Text(text);
        textObj.setFont(font);
        double textWidth = textObj.getLayoutBounds().getWidth();
        gc.fillText(text,rightX - textWidth - 10,rightY + font.getSize()/2);
    }

    //method to open Sankey Diagram
    private void openSankeyDiagram() {
        Stage sankeyStage = new Stage();
        StackPane sankey = new StackPane();
        Canvas canvas = new Canvas();
        GraphicsContext gc = canvas.getGraphicsContext2D();
        sankey.getChildren().add(canvas);

        //resizable
        canvas.widthProperty().bind(sankey.widthProperty());
        canvas.heightProperty().bind(sankey.heightProperty());
        canvas.widthProperty().addListener(observable -> drawSankeyDiagram(gc, canvas.getWidth(), canvas.getHeight()));
        canvas.heightProperty().addListener(observable -> drawSankeyDiagram(gc, canvas.getWidth(), canvas.getHeight()));

        sankeyStage.setTitle(title);
        sankeyStage.setScene(new Scene(sankey,700,700));
        //set min to show full information
        sankeyStage.setMinWidth(500);
        sankeyStage.setMinHeight(300);
        sankeyStage.show();

        drawSankeyDiagram(gc,700,700);
    }

    //method to draw Sankey Diagram
    private void drawSankeyDiagram(GraphicsContext gc,double x,double y) {
        gc.clearRect(0,0,x,y);

        //resizable
        double rightY = 0.3*y;
        double rightX = 0.8*x;
        double total_height = 0.2*y;
        double width = 0.04*x;
        double spacing = 0.2*y/(map.size()-1);
        double leftY = 0.4*y;
        double leftX = 0.3*x;

        //adapt to the text size
        if (map.size() >= 8) {
            rightY = 0.2*y;
            spacing = 0.4*y/(map.size()-1);
        }

        //draw left rectangles
        drawRectangle(gc,leftX-width, leftY, width, total_height,Color.color(0.53,0.81,0.92,0.7));

        //draw left texts
        drawText(gc,total_key + ": " + total_value,leftX-width,(2*leftY+total_height)/2,new Font("Arial",15));

        int i = 0;
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            double single_height = total_height * (entry.getValue() / (double) total_value);

            //draw right rectangles
            drawRectangle(gc,rightX, rightY, width, single_height,colorList.get(i % colorList.size()).getColor1());

            //draw right texts
            drawText(gc,entry.getKey()+": "+entry.getValue(),rightX,rightY + single_height/2,new Font("Arial",15));

            //draw curves
            drawCurve(gc,leftX,leftY,rightX,rightY,single_height,colorList.get(i % colorList.size()).getColor2());

            //move to next position
            leftY += single_height;
            rightY += spacing + single_height;
            i++;
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}